import { NextRequest, NextResponse } from 'next/server'
import { requireAdmin } from '@/lib/apiAuth'
import { getAdminClient } from '@/lib/supabaseAdmin'
import { appointmentEventAttendees } from '@/lib/appointments/calendarSync'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAdmin(req)
  if (auth.err) return auth.err
  const { id } = await params
  const admin = getAdminClient()
  const { data: appointment, error } = await admin
    .from('appointments')
    .select('*')
    .eq('id', id)
    .maybeSingle()
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  if (!appointment) return NextResponse.json({ error: 'Appointment not found' }, { status: 404 })

  const matterId = appointment.linked_matter_id as string | null
  let calendarAttendees: Awaited<ReturnType<typeof appointmentEventAttendees>> = []
  try {
    calendarAttendees = await appointmentEventAttendees(appointment)
  } catch {
    // A calendar connection failure leaves the local invite data usable.
  }
  const localAttendees = [
    { name: appointment.attendee_name, email: appointment.attendee_email, status: 'invited' },
    ...(appointment.second_attendee_email ? [{
      name: appointment.second_attendee_name ?? appointment.second_attendee_email,
      email: appointment.second_attendee_email,
      status: 'invited',
    }] : []),
  ]
  const attendees = calendarAttendees.length > 0 ? calendarAttendees : localAttendees
  // EXTRACTED: Cornerstone added a matter panel here (stage, estate-tax
  // exposure, open tasks, recent documents) when the appointment is linked to a
  // matter. Return your own linked-record summary in `matter` if you want one.
  void matterId
  return NextResponse.json({
    appointment,
    matter: null,
    checklist: [],
    documents: [],
    attendees,
  })
}
