// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
'use client'
export function ClientErrorState({ reset }: { error?: Error; reset?: () => void; [k: string]: unknown }) {
  return (
    <div className="mx-auto max-w-md p-8 text-center">
      <p className="text-lg font-medium">Something went wrong.</p>
      {reset && <button className="mt-4 underline" onClick={() => reset()}>Try again</button>}
    </div>
  )
}
