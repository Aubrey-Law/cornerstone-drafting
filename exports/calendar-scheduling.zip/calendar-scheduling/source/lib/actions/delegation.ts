// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
// Cornerstone's "delegation dial" (propose / act / observe per action).
// Returning null makes delegateAppointmentConfirmation fall back to sending the
// confirmation email directly, which is the behavior you want in a new app.
export async function resolveUnattendedActor(): Promise<{ id: string } | null> {
  return null
}
