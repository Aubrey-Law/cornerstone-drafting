// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
export class ActionServiceError extends Error {
  constructor(public code: string, message?: string) {
    super(message ?? code)
  }
}
