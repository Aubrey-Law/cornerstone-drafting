// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
export async function createActionProposal(..._args: unknown[]): Promise<{
  autonomy?: string
  duplicate?: boolean
  execution?: { status: string } | null
}> {
  throw new Error('Action proposals are not wired in this app')
}
