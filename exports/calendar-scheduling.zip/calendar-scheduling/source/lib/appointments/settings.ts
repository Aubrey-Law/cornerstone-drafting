import 'server-only'
import { getAdminClient } from '@/lib/supabaseAdmin'
import { sanitizeCalendlyUrls } from '@/lib/calendly/links'
import { sanitizeBookingQuestions } from './bookingQuestions'
import { sanitizeCalendarIds } from './calendarSelection'
import {
  appointmentTypeFromRow,
  emptyWeeklyHours,
  isAppointmentLocationType,
  sanitizeCustomWeeklyHours,
  sanitizeDateOverrides,
  sanitizeWeeklyHours,
  type AppointmentType,
  type AppointmentTypeRow,
  type SchedulingSettings,
} from './types'

export { sanitizeWeeklyHours }

interface SchedulingSettingsRow {
  timezone: string | null
  weekly_hours: unknown
  min_notice_hours: number | null
  horizon_days: number | null
  buffer_minutes: number | null
  reminder_hours_before: number | null
  booking_paused: boolean | null
  sms_reminders_enabled: boolean | null
  auto_intake_invite: boolean | null
  date_overrides: unknown
  calendly_urls: unknown
  hidden_calendar_ids: unknown
  blocking_calendar_ids: unknown
}

const TTL_MS = 30_000
let settingsCache: { value: SchedulingSettings; at: number } | null = null
let typesCache: { value: AppointmentType[]; at: number } | null = null

function defaults(): SchedulingSettings {
  const hours = emptyWeeklyHours()
  for (const day of ['mon', 'tue', 'wed', 'thu', 'fri'] as const) {
    hours[day] = [{ start: '09:00', end: '17:00' }]
  }
  return {
    timezone: 'America/New_York',
    weeklyHours: hours,
    minNoticeHours: 24,
    horizonDays: 30,
    bufferMinutes: 15,
    reminderHoursBefore: 24,
    bookingPaused: false,
    smsRemindersEnabled: false,
    autoIntakeInvite: true,
    dateOverrides: {},
    calendlyUrls: {},
    hiddenCalendarIds: [],
    blockingCalendarIds: [],
  }
}

export async function getSchedulingSettings(): Promise<SchedulingSettings> {
  if (settingsCache && Date.now() - settingsCache.at < TTL_MS) return settingsCache.value

  const { data } = await getAdminClient()
    .from('scheduling_settings')
    .select('timezone, weekly_hours, min_notice_hours, horizon_days, buffer_minutes, reminder_hours_before, booking_paused, sms_reminders_enabled, auto_intake_invite, date_overrides, calendly_urls, hidden_calendar_ids, blocking_calendar_ids')
    .eq('id', 1)
    .maybeSingle()

  const base = defaults()
  const row = data as SchedulingSettingsRow | null
  const value: SchedulingSettings = row
    ? {
        timezone: row.timezone?.trim() || base.timezone,
        weeklyHours: sanitizeWeeklyHours(row.weekly_hours),
        minNoticeHours: row.min_notice_hours ?? base.minNoticeHours,
        horizonDays: row.horizon_days ?? base.horizonDays,
        bufferMinutes: row.buffer_minutes ?? base.bufferMinutes,
        reminderHoursBefore: row.reminder_hours_before ?? base.reminderHoursBefore,
        bookingPaused: row.booking_paused ?? base.bookingPaused,
        smsRemindersEnabled: false,
        autoIntakeInvite: row.auto_intake_invite ?? base.autoIntakeInvite,
        dateOverrides: sanitizeDateOverrides(row.date_overrides),
        calendlyUrls: sanitizeCalendlyUrls(row.calendly_urls),
        hiddenCalendarIds: sanitizeCalendarIds(row.hidden_calendar_ids),
        blockingCalendarIds: sanitizeCalendarIds(row.blocking_calendar_ids),
      }
    : base

  settingsCache = { value, at: Date.now() }
  return value
}

export interface UpdateSchedulingSettingsInput {
  timezone?: string
  weeklyHours?: unknown
  minNoticeHours?: number
  horizonDays?: number
  bufferMinutes?: number
  reminderHoursBefore?: number
  bookingPaused?: boolean
  smsRemindersEnabled?: boolean
  autoIntakeInvite?: boolean
  dateOverrides?: unknown
  calendlyUrls?: unknown
  hiddenCalendarIds?: unknown
  blockingCalendarIds?: unknown
  updatedBy?: string | null
}

export async function updateSchedulingSettings(
  input: UpdateSchedulingSettingsInput,
): Promise<void> {
  const patch: Record<string, unknown> = { id: 1, updated_at: new Date().toISOString() }
  if (input.timezone !== undefined) patch.timezone = input.timezone
  if (input.weeklyHours !== undefined) patch.weekly_hours = sanitizeWeeklyHours(input.weeklyHours)
  if (input.minNoticeHours !== undefined) patch.min_notice_hours = input.minNoticeHours
  if (input.horizonDays !== undefined) patch.horizon_days = input.horizonDays
  if (input.bufferMinutes !== undefined) patch.buffer_minutes = input.bufferMinutes
  if (input.reminderHoursBefore !== undefined) patch.reminder_hours_before = input.reminderHoursBefore
  if (input.bookingPaused !== undefined) patch.booking_paused = input.bookingPaused
  if (input.smsRemindersEnabled !== undefined) patch.sms_reminders_enabled = false
  if (input.autoIntakeInvite !== undefined) patch.auto_intake_invite = input.autoIntakeInvite
  if (input.dateOverrides !== undefined) patch.date_overrides = sanitizeDateOverrides(input.dateOverrides)
  if (input.calendlyUrls !== undefined) patch.calendly_urls = sanitizeCalendlyUrls(input.calendlyUrls)
  if (input.hiddenCalendarIds !== undefined) {
    patch.hidden_calendar_ids = sanitizeCalendarIds(input.hiddenCalendarIds)
  }
  if (input.blockingCalendarIds !== undefined) {
    patch.blocking_calendar_ids = sanitizeCalendarIds(input.blockingCalendarIds)
  }
  if (input.updatedBy !== undefined) patch.updated_by = input.updatedBy

  const { error } = await getAdminClient()
    .from('scheduling_settings')
    .upsert(patch, { onConflict: 'id' })
  if (error) throw error
  settingsCache = null
}

/** Postgres undefined_column, or PostgREST's schema-cache miss for a column. */
export function isMissingColumnError(error: { code?: string } | null): boolean {
  return error?.code === '42703' || error?.code === 'PGRST204'
}

export async function listAppointmentTypes(): Promise<AppointmentType[]> {
  if (typesCache && Date.now() - typesCache.at < TTL_MS) return typesCache.value

  const base =
    'id, key, slug, label, description, duration_minutes, location_type, location_types, active, public, sort, custom_weekly_hours'
  const query = (columns: string) =>
    getAdminClient().from('appointment_types').select(columns).order('sort', { ascending: true })
  const first = await query(`${base}, booking_questions`)
  // Code and migrations deploy in no guaranteed order: until booking_questions
  // exists, read without it rather than taking every booking page down.
  const { data } = first.error && isMissingColumnError(first.error) ? await query(base) : first

  const value = ((data ?? []) as unknown as AppointmentTypeRow[]).map(appointmentTypeFromRow)
  typesCache = { value, at: Date.now() }
  return value
}

export async function getAppointmentTypeBySlug(slug: string): Promise<AppointmentType | null> {
  const types = await listAppointmentTypes()
  return types.find(t => t.slug === slug.trim()) ?? null
}

export async function getAppointmentTypeByKey(key: string): Promise<AppointmentType | null> {
  const types = await listAppointmentTypes()
  return types.find(t => t.key === key.trim()) ?? null
}

export interface UpdateAppointmentTypeInput {
  id: string
  label?: string
  description?: string
  durationMinutes?: number
  locationType?: string
  /** Ordered allowed formats; first entry becomes the default location_type. */
  locationTypes?: unknown
  active?: boolean
  public?: boolean
  sort?: number
  /** null clears the override (use general hours); an object limits the type to those windows. */
  customWeeklyHours?: unknown
  /** Full replacement list; sanitized (invalid questions are dropped). */
  bookingQuestions?: unknown
}

export async function updateAppointmentType(input: UpdateAppointmentTypeInput): Promise<void> {
  const patch: Record<string, unknown> = {}
  if (input.label !== undefined) patch.label = input.label
  if (input.description !== undefined) patch.description = input.description
  if (input.durationMinutes !== undefined) patch.duration_minutes = input.durationMinutes
  if (input.locationType !== undefined) patch.location_type = input.locationType
  if (input.locationTypes !== undefined) {
    const list = Array.isArray(input.locationTypes)
      ? [...new Set(input.locationTypes.filter(isAppointmentLocationType))]
      : []
    if (list.length > 0) {
      patch.location_types = list
      // Keep the legacy single-format column synced to the default.
      patch.location_type = list[0]
    }
  }
  if (input.active !== undefined) patch.active = input.active
  if (input.public !== undefined) patch.public = input.public
  if (input.sort !== undefined) patch.sort = input.sort
  if (input.customWeeklyHours !== undefined) {
    patch.custom_weekly_hours = sanitizeCustomWeeklyHours(input.customWeeklyHours)
  }
  if (input.bookingQuestions !== undefined) {
    patch.booking_questions = sanitizeBookingQuestions(input.bookingQuestions)
  }
  if (Object.keys(patch).length === 0) return

  const update = (values: Record<string, unknown>) =>
    getAdminClient().from('appointment_types').update(values).eq('id', input.id)
  let { error } = await update(patch)
  // Same deploy-order guard as listAppointmentTypes: save everything else
  // while booking_questions doesn't exist yet.
  if (error && isMissingColumnError(error) && 'booking_questions' in patch) {
    const { booking_questions: _pending, ...rest } = patch
    ;({ error } = Object.keys(rest).length > 0 ? await update(rest) : { error: null })
  }
  if (error) throw error
  typesCache = null
}

/** Test-only: reset module caches. */
export function __resetSchedulingCaches(): void {
  settingsCache = null
  typesCache = null
}
