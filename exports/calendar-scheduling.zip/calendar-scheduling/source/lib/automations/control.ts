// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
// Cornerstone wraps cron jobs in a kill-switch/run-ledger (automation_rules).
// This keeps only the part the reminder cron needs: the CRON_SECRET check.
export async function runSystemAutomation(
  _key: string,
  request: Request,
  execute: () => Promise<Response>,
  _options: { leaseSeconds?: number; now?: Date } = {},
): Promise<Response> {
  const secret = process.env.CRON_SECRET
  if (!secret || request.headers.get('authorization') !== `Bearer ${secret}`) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 })
  }
  return execute()
}
