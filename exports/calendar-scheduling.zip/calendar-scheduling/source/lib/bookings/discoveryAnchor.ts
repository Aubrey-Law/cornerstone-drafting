// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
// Cornerstone stamps the discovery-call date onto the lead to start SLA clocks.
export interface DiscoveryAnchorInput {
  leadId: string | null
  matterId: string | null
  startIso: string
  overwrite?: boolean
}
export async function recordDiscoveryAnchor(_admin: unknown, _input: DiscoveryAnchorInput): Promise<void> {}
