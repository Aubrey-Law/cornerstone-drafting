// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
// Cornerstone stamps the planning-session date onto the matter for SLA clocks.
export async function recordPmpsAnchor(
  _admin: unknown,
  _input: { leadId: string | null; matterId: string | null; startIso: string },
): Promise<void> {}
