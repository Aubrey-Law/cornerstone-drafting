// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
// Cornerstone links a booking to an existing lead (client_intake) or hired
// matter by attendee email. Point these at your own contacts/customers table.
export interface LeadLookupRow {
  id: string
  lead_status: string | null
  first_name: string | null
  last_name: string | null
  full_name: string | null
  email: string | null
  phone: string | null
  lead_source: string | null
}
export async function findLeadByEmail(_admin: unknown, _attendeeEmail: string): Promise<LeadLookupRow | null> {
  return null
}
export async function findMatterIdByEmail(_admin: unknown, _attendeeEmail: string): Promise<string | null> {
  return null
}
