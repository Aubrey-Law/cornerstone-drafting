// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
// Cornerstone derives "needs attention" items (unsigned engagement, missing
// intake, upcoming key dates) from matter data for the calendar's day rail.
import type { AttentionItem, CalendarRailData } from '@/app/admin/calendar/types'

export async function deriveCalendarAttention(_date: string): Promise<{
  items: AttentionItem[]
  rail: Omit<CalendarRailData, 'openSlots'>
}> {
  return { items: [], rail: { datesThisWeek: [], followUps: [] } }
}
