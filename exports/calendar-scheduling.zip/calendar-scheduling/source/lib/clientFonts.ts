// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
// Cornerstone loads local brand fonts via next/font/local. Swap in your own.
export const clientSerifClass = ''
export const guidedFontClass = ''
