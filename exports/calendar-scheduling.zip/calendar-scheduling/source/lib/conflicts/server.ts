// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
// Cornerstone runs a conflict-of-interest check on every new lead.
export function scheduleConflictCheck(_leadId: string): void {}
