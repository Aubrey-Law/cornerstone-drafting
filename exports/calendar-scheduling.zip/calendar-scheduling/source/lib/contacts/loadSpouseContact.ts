// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
// Cornerstone pre-fills a second attendee (spouse/partner) from the matter.
export async function loadSpouseContact(
  _admin: unknown,
  _matterId: string,
  _select?: string,
): Promise<{ first_name?: string | null; last_name?: string | null; full_name?: string | null; email?: string | null; phone?: string | null } | null> {
  return null
}
