// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
// Cornerstone's sender adds stored templates, Gmail-as-staff, attachment
// handling and a send log. This is a minimal Resend sender with the same shape.
import { Resend } from 'resend'

export interface SendEmailArgs {
  category?: string
  to: string
  cc?: string | string[]
  bcc?: string | string[]
  replyTo?: string
  subject: string
  html: string
  text?: string
  useStoredTemplate?: boolean
  leadId?: string | null
  matterId?: string | null
  [extra: string]: unknown
}

export type SendEmailResult =
  | { ok: true; status: 'sent'; providerMessageId: string | null; logId: string | null }
  | { ok: true; status: 'logged'; reason: 'no_api_key'; logId: string | null }
  | { ok: false; status: 'error'; error: string; logId: string | null }

export async function sendEmail(args: SendEmailArgs): Promise<SendEmailResult> {
  const key = process.env.RESEND_API_KEY
  const from = process.env.RESEND_FROM
  if (!key || !from) {
    console.warn('[email] RESEND_API_KEY/RESEND_FROM not set; skipping', args.category, args.subject)
    return { ok: true, status: 'logged', reason: 'no_api_key', logId: null }
  }
  const { data, error } = await new Resend(key).emails.send({
    from,
    to: args.to,
    cc: args.cc,
    bcc: args.bcc,
    replyTo: args.replyTo,
    subject: args.subject,
    html: args.html,
    text: args.text,
  })
  if (error) return { ok: false, status: 'error', error: error.message, logId: null }
  return { ok: true, status: 'sent', providerMessageId: data?.id ?? null, logId: null }
}
