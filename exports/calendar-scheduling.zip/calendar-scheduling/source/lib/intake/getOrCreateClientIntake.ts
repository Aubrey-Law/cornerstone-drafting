// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
// Portal /schedule uses the client's intake row to prefill name/email and to
// link the booking. Return your logged-in customer's record here.
import type { SupabaseClient } from '@supabase/supabase-js'
export interface ClientIntakeRow {
  id: string
  first_name?: string | null
  last_name?: string | null
  full_name?: string | null
  email?: string | null
  phone?: string | null
  [column: string]: unknown
}
export async function findClientIntakeForUser(
  _supabase: SupabaseClient,
  _userId: string,
  _preferredId?: string | null,
): Promise<ClientIntakeRow | null> {
  return null
}
