// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
// Cornerstone mints a standing intake-questionnaire link for each new lead.
import { randomUUID } from 'node:crypto'
export function createStandingIntakeVersion(): string {
  return randomUUID()
}
export async function ensureStandingIntakeLink(
  _admin: unknown,
  _intakeId: string,
  _reviveRevoked = true,
): Promise<{ url: string | null; version: string; createdAt: string; revoked?: boolean }> {
  return { url: null, version: '', createdAt: new Date().toISOString() }
}
