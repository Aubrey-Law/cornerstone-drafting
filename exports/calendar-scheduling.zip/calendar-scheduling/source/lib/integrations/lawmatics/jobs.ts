// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
// Cornerstone mirrors appointments into Lawmatics via a job queue.
export async function enqueueLawmaticsAppointmentSync(
  _appointmentId: string,
  _actorId?: string | null,
  _options: { reopenTerminal?: boolean; sourceVersion?: string } = {},
): Promise<void> {}
