// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
// Cornerstone emails a client when staff post a portal message.
export async function notifyClientOfFirmMessage(_matterId: string): Promise<void> {}
