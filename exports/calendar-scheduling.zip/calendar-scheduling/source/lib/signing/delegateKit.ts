// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
// Cornerstone prepares a signing kit when a signing appointment is booked.
export async function delegateSigningKit(_input: { matterId: string; scheduledFor: string | null; actorId?: string | null }): Promise<void> {}
