// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
// Cornerstone creates stage tasks when a booking advances a matter's stage.
export async function fireEngineStageTask(_admin: unknown, _args: { matterId: string; matterStage: string; [k: string]: unknown }): Promise<void> {}
