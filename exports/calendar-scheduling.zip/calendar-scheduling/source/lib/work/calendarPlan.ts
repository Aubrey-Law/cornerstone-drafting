// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
// Cornerstone's Plan view shows a prioritized daily work plan built from its
// task/work graph. Only the type survives here; the trimmed plan route returns
// an empty plan so the view renders without that system.
export interface CalendarPlanItem {
  workKey: string
  title: string
  href: string
  recordName: string
  priorityBand: 0 | 1 | 2 | 3 | 4
  priorityReasons: string[]
  estimateMinutes: number
  lane: string
  blockStart: string | null
  blockEnd: string | null
  state: string
  itemStatus: 'planned' | 'started' | 'completed' | 'skipped'
  itemCount: number
}

export interface CalendarTodayPlan {
  date: string
  status: 'draft' | 'committed' | 'closed' | 'uncommitted'
  capacityMinutes: number
  plannedMinutes: number
  overload: boolean
  overloadMinutes: number
  items: CalendarPlanItem[]
}
