// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
// Cornerstone's matter pipeline stages. automation.ts advances a matter's
// stage when certain appointment types are booked; adapt or remove.
export type MatterStage = string
export function stageLabel(stage: string): string {
  return stage.replace(/_/g, ' ')
}
