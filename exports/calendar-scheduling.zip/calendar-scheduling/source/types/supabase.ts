// HOST ADAPTER (stub). Cornerstone-specific in the source app; replace with your
// app's equivalent or leave as a no-op. See exports/calendar-scheduling/README.md.
// Replace with your generated types:
//   npx supabase gen types typescript --local > types/supabase.ts
// Until then the scheduling tables are untyped.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type Database = any
