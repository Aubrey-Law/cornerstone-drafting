'use client'

import { useMemo, type ReactNode } from 'react'
import { Checkbox } from '@/components/ui/checkbox'
import { cn } from '@/lib/utils'
import type { MatterContact } from '@/types/database'
import {
  getDocumentInclusions,
  getEstatePlanDesignSetup,
  setEstatePlanDesignSetup,
  type EstatePlanAncillaryDocumentKey,
  type EstatePlanComprehensiveTransferTitle,
  type EstatePlanHealthcareDirectiveTitle,
  type EstatePlanPoaForm,
  type EstatePlanPoaTitle,
  mergeDecisionUpdates,
  setDocumentInclusion,
} from '@/lib/designSheetDocumentInclusions'
import { resolveResidualBeneficiaryMethod } from '@/lib/designSheetTrustDetails'
import {
  getPersistedRealEstateTransfer,
  setSelectedAssetTransferDocs,
} from '@/lib/designSheetRealEstateTransfer'
import {
  DOCUMENT_TYPES,
  REAL_ESTATE_TRANSFER_DOC_TYPES,
  type RealEstateTransferDocType,
} from '@/lib/realEstateTransfer/fields'
import {
  DESIGN_PLAN_TYPE_OPTIONS,
  designPlanTypeIncludesRevocableTrust,
  normalizeDesignPlanType,
  planTypeDisallowsRevocableTrustDocument,
} from '@/lib/designPlanType'
import { applyDesignPlanType } from '@/lib/designSheet/applyPlanType'
import {
  AttorneyNoteBanner,
  AttorneySelect,
  ClientDecisionCallout,
  DecisionRow,
  DesignSectionContent,
  SectionBlock,
  sectionFieldGrid2,
  sectionFieldGrid3,
  type SectionProps,
} from './shared'
import { PlanStructureFactsSection } from './PlanStructureFactsSection'
import { PlanTrackNotice } from './PlanTrackNotice'

interface PlanDesignSectionProps extends SectionProps {
  matterId: string
  practiceArea: string | null
  contacts?: MatterContact[]
  onAddContact?: (data: Omit<MatterContact, 'id'>) => Promise<MatterContact>
  onUpdateContact?: (id: string, data: Omit<MatterContact, 'id'>) => Promise<MatterContact>
  showInapplicable?: boolean
}

const FUNDING_DOCUMENT_LABELS: Record<
  'certificate_of_trust' | 'assignment_of_personal_property' | 'funding_instructions' | 'funding_recommendation' | 'homestead_trustee',
  string
> = {
  certificate_of_trust: 'Certificate of Trust',
  assignment_of_personal_property: 'Assignment of Personal Property',
  funding_instructions: 'Funding Instructions',
  funding_recommendation: 'Funding Recommendation',
  homestead_trustee: 'Declaration of Homestead (Trustee)',
}

/**
 * Captured but never drafted. The design sheet records the decision and the
 * interview worksheet prints it; no template produces these documents yet, so
 * the UI says so rather than letting a ticked box imply a deliverable.
 */
const RECORD_ONLY_DOCUMENT_LABELS: Record<
  'dementia_directive' | 'visitation_authorization' | 'final_disposition' | 'comprehensive_transfer_document' | 'client_self_declaration_of_capacity',
  string
> = {
  dementia_directive: 'Dementia Directive',
  visitation_authorization: 'Visitation Authorization',
  final_disposition: 'Final Disposition Instructions',
  comprehensive_transfer_document: 'Comprehensive Transfer Document',
  client_self_declaration_of_capacity: 'Client Self-Declaration of Capacity',
}

const HEALTHCARE_DIRECTIVE_TITLE_OPTIONS = [
  { value: 'state_default', label: 'State Default (Health Care Proxy)' },
  { value: 'advance_directive', label: 'Advance Directive' },
  { value: 'advance_health_care_directive', label: 'Advance Health Care Directive' },
  { value: 'health_care_directive', label: 'Health Care Directive' },
  { value: 'health_care_power_of_attorney', label: 'Health Care Power of Attorney' },
  { value: 'other', label: 'Other' },
]

const POA_FORM_OPTIONS = [
  { value: 'short', label: 'Short form' },
  { value: 'long', label: 'Long form' },
  { value: 'both', label: 'Both forms' },
]

const POA_TITLE_OPTIONS = [
  { value: 'power_of_attorney', label: 'Power of Attorney' },
  { value: 'durable_power_of_attorney', label: 'Durable Power of Attorney' },
]

const COMPREHENSIVE_TRANSFER_TITLE_OPTIONS = [
  { value: 'declaration_of_trust', label: 'Declaration of Trust' },
  { value: 'comprehensive_transfer_of_assets', label: 'Comprehensive Transfer of Assets' },
  { value: 'general_assignment', label: 'General Assignment' },
]

const ANCILLARY_DOCUMENT_LABELS: Record<
  'trust_summary' | 'estate_plan_summary' | 'estate_plan_signing_guide' | 'successor_trustee_checklist' | 'fiduciary_role_guide' | 'flowchart' | 'include_asset_spreadsheet',
  string
> = {
  trust_summary: 'Trust Summary',
  estate_plan_summary: 'Estate Plan Summary',
  estate_plan_signing_guide: 'Estate Plan Signing Guide',
  successor_trustee_checklist: 'Successor Trustee Checklist',
  fiduciary_role_guide: 'Fiduciary Role Guide',
  flowchart: 'Flowchart',
  include_asset_spreadsheet: 'Include Asset Spreadsheet',
}

type RecordOnlyDocumentKey = keyof typeof RECORD_ONLY_DOCUMENT_LABELS
type FundingDocumentKey = keyof typeof FUNDING_DOCUMENT_LABELS
type StandaloneAncillaryDocumentKey = keyof typeof ANCILLARY_DOCUMENT_LABELS

export function PlanTypeBlock({ sheet, onChange }: SectionProps) {
  const normalizedPlanType = normalizeDesignPlanType(sheet.plan_type)

  const handlePlanTypeSelect = (value: string) => {
    const nextPlanType = normalizeDesignPlanType(value)
    if (!nextPlanType) return
    onChange('plan_type', () => nextPlanType)
    onChange('decisions', prevSheet => {
      const applied = applyDesignPlanType(prevSheet, nextPlanType)
      if (!applied.decisions) return prevSheet.decisions ?? {}
      return applied.decisions
    })
  }

  return (
    <SectionBlock title="Plan Type">
      <DecisionRow
        question="Plan type"
        help="Choose the structure that controls the document package and downstream drafting choices."
        fieldName="plan_type"
        blocking
        options={DESIGN_PLAN_TYPE_OPTIONS.map((opt) => ({
          value: opt.value,
          label: opt.label,
        }))}
        value={normalizedPlanType}
        onChange={handlePlanTypeSelect}
      />
    </SectionBlock>
  )
}

export function AssetTransferDocumentsFields({ sheet, onChange }: SectionProps) {
  const selectedAssetTransferDocs = useMemo(
    () => new Set(getPersistedRealEstateTransfer(sheet).selectedDocs),
    [sheet],
  )

  const updateAssetTransferDoc = (docType: RealEstateTransferDocType, checked: boolean) => {
    const next = new Set(selectedAssetTransferDocs)
    if (checked) next.add(docType)
    else next.delete(docType)
    onChange('decisions', prevSheet => setSelectedAssetTransferDocs(prevSheet, Array.from(next)))
  }

  return (
    <div className="space-y-3">
      {REAL_ESTATE_TRANSFER_DOC_TYPES.map(docType => (
        <label
          key={docType}
          className="flex items-start gap-3 rounded-md border border-border bg-muted px-3 py-2.5"
        >
          <Checkbox
            checked={selectedAssetTransferDocs.has(docType)}
            onCheckedChange={value => updateAssetTransferDoc(docType, value === true)}
          />
          <span className="text-sm text-foreground">{DOCUMENT_TYPES[docType].label}</span>
        </label>
      ))}
    </div>
  )
}

function ApplicableDecision({
  applicable,
  showInapplicable,
  children,
}: {
  applicable: boolean
  showInapplicable: boolean
  children: ReactNode
}) {
  if (!applicable && !showInapplicable) return null
  return <div className={!applicable ? 'opacity-45 grayscale-[20%]' : undefined}>{children}</div>
}

export function PlanDesignSection({
  sheet,
  onChange,
  matterId,
  practiceArea,
  contacts: _contacts = [],
  onAddContact: _onAddContact,
  onUpdateContact: _onUpdateContact,
  showInapplicable = false,
}: PlanDesignSectionProps) {
  const normalizedPlanType = normalizeDesignPlanType(sheet.plan_type)
  const inclusions = getDocumentInclusions(sheet)
  const estatePlanSetup = getEstatePlanDesignSetup(sheet)
  const needsDistributionMethod = resolveResidualBeneficiaryMethod(sheet) == null
  const isMarried = sheet.matter_type === 'couple'
  const fundingDocKeys: FundingDocumentKey[] = [
    'certificate_of_trust',
    'assignment_of_personal_property',
    'funding_instructions',
    'funding_recommendation',
    'homestead_trustee',
  ]
  const recordOnlyKeys: RecordOnlyDocumentKey[] = [
    'dementia_directive',
    'visitation_authorization',
    'final_disposition',
    'comprehensive_transfer_document',
    'client_self_declaration_of_capacity',
  ]
  const standaloneAncillaryKeys: StandaloneAncillaryDocumentKey[] = [
    'trust_summary',
    'estate_plan_summary',
    'estate_plan_signing_guide',
    'successor_trustee_checklist',
    'fiduciary_role_guide',
    'flowchart',
    'include_asset_spreadsheet',
  ]

  const updateDecisions = (
    ...updates: Array<(current: Pick<typeof sheet, 'decisions'>) => Record<string, unknown>>
  ) => {
    onChange('decisions', prevSheet => mergeDecisionUpdates(prevSheet, ...updates))
  }

  const updateDocument = (key: keyof typeof inclusions, checked: boolean) => {
    updateDecisions(current => setDocumentInclusion(current, key, checked))
  }

  const updateEstatePlanSetup = (patch: Parameters<typeof setEstatePlanDesignSetup>[1]) => {
    updateDecisions(current => setEstatePlanDesignSetup(current, patch))
  }

  const updateCoreDocument = (
    key: 'trust' | 'will' | 'power_of_attorney' | 'health_care_proxy' | 'hipaa_authorization' | 'living_will',
    checked: boolean,
  ) => {
    if (key === 'trust') {
      if (planTypeDisallowsRevocableTrustDocument(normalizedPlanType)) return
      updateDecisions(
        current => setDocumentInclusion(current, 'trust', checked),
        current => setEstatePlanDesignSetup(current, {
          trust: checked,
          will_title: checked ? 'pour_over_will' : 'last_will',
        }),
      )
      return
    }
    if (key === 'will') {
      updateDecisions(
        current => setDocumentInclusion(current, 'will', checked),
        current => setEstatePlanDesignSetup(current, { will: checked }),
      )
      return
    }
    if (key === 'power_of_attorney') {
      updateDecisions(
        current => setDocumentInclusion(current, 'dpoa', checked),
        current => setEstatePlanDesignSetup(current, { power_of_attorney: checked }),
      )
      return
    }

    const nextHealthcare = {
      health_care_proxy: key === 'health_care_proxy' ? checked : estatePlanSetup.health_care_proxy,
      hipaa_authorization: key === 'hipaa_authorization' ? checked : estatePlanSetup.hipaa_authorization,
      living_will: key === 'living_will' ? checked : estatePlanSetup.living_will,
    }
    updateDecisions(
      current => setDocumentInclusion(current, 'healthcare', Object.values(nextHealthcare).some(Boolean)),
      current => setEstatePlanDesignSetup(current, {
        health_care_proxy: nextHealthcare.health_care_proxy,
        hipaa_authorization: nextHealthcare.hipaa_authorization,
        living_will: nextHealthcare.living_will,
      }),
    )
  }

  const updateAncillaryDocument = (key: EstatePlanAncillaryDocumentKey, checked: boolean) => {
    updateEstatePlanSetup({
      ancillary_documents: {
        ...estatePlanSetup.ancillary_documents,
        [key]: checked,
      },
    })
  }

  const trustCheckboxDisabled = planTypeDisallowsRevocableTrustDocument(normalizedPlanType)
  const revocableTrustDecisionApplies = normalizedPlanType == null
    || designPlanTypeIncludesRevocableTrust(normalizedPlanType)

  return (
    <DesignSectionContent>
      <AttorneyNoteBanner>
        Select the documents for this matter first. The checked documents control which sections appear below and which drafts are generated.
      </AttorneyNoteBanner>

      <PlanTrackNotice matterId={matterId} practiceArea={practiceArea} />

      <PlanTypeBlock sheet={sheet} onChange={onChange} />

      <SectionBlock title="Documents Included">
        {needsDistributionMethod && (
          <ClientDecisionCallout>distribution method not yet selected</ClientDecisionCallout>
        )}
        <div className="space-y-5 pt-1">
          <div>
            <p className="mb-3 text-micro font-bold uppercase tracking-[0.12em] text-muted-foreground">Core Documents</p>
            <div className="space-y-3">
              {[
                { key: 'trust', label: 'Trust' },
                { key: 'will', label: 'Will' },
                { key: 'power_of_attorney', label: 'Power of Attorney' },
                { key: 'health_care_proxy', label: 'Health Care Proxy' },
                { key: 'hipaa_authorization', label: 'HIPAA Authorization' },
                { key: 'living_will', label: 'Living Will' },
              ].map(item => {
                const isTrust = item.key === 'trust'
                const applicable = !isTrust || revocableTrustDecisionApplies
                const disabled = isTrust && trustCheckboxDisabled
                return (
                <ApplicableDecision key={item.key} applicable={applicable} showInapplicable={showInapplicable}>
                <label
                  className={cn(
                    'flex items-start gap-3 rounded-md border border-border bg-muted px-3 py-2.5',
                    disabled && 'cursor-not-allowed opacity-60',
                  )}
                >
                  <Checkbox
                    checked={!disabled && estatePlanSetup[item.key as keyof typeof estatePlanSetup] === true}
                    disabled={disabled}
                    onCheckedChange={value => {
                      if (disabled) return
                      updateCoreDocument(item.key as Parameters<typeof updateCoreDocument>[0], value === true)
                    }}
                  />
                  <span className="text-sm text-foreground">
                    {item.label}
                    {disabled && (
                      <span className="mt-0.5 block text-xs text-muted-foreground">
                        Not available with Will — Testamentary Trust. The testamentary trust is created under the will, not as a separate revocable trust document.
                      </span>
                    )}
                  </span>
                </label>
                </ApplicableDecision>
                )
              })}
            </div>
          </div>

          {isMarried && (
            <div className="rounded-lg border border-border bg-muted p-4">
              <label className="flex cursor-pointer items-center gap-3">
                <Checkbox checked={inclusions.spouse_docs} onCheckedChange={value => updateDocument('spouse_docs', value === true)} />
                <span>
                  <span className="block text-sm font-semibold text-foreground">Generate spouse / partner documents</span>
                  <span className="block text-xs text-muted-foreground">Applies to Will, DPOA, and Health Care document packages when selected.</span>
                </span>
              </label>
            </div>
          )}

          <div>
            <p className="mb-3 text-micro font-bold uppercase tracking-[0.12em] text-muted-foreground">Ancillary Documents</p>
            <div className="space-y-3">
              <ApplicableDecision
                applicable={revocableTrustDecisionApplies}
                showInapplicable={showInapplicable}
              >
              <div className="rounded-md border border-border bg-muted p-4">
                <p className="mb-3 text-sm font-semibold text-foreground">Funding Documents</p>
                <div className="space-y-2">
                  {fundingDocKeys.map(key => (
                    <label key={key} className="flex items-start gap-3">
                      <Checkbox
                        checked={estatePlanSetup.ancillary_documents[key]}
                        onCheckedChange={value => updateAncillaryDocument(key, value === true)}
                      />
                      <span className="text-sm text-foreground">{FUNDING_DOCUMENT_LABELS[key]}</span>
                    </label>
                  ))}
                </div>
              </div>
              </ApplicableDecision>

              <div className={sectionFieldGrid2}>
                {standaloneAncillaryKeys.map(key => {
                  const trustOnly = key === 'trust_summary' || key === 'successor_trustee_checklist'
                  return (
                  <ApplicableDecision
                    key={key}
                    applicable={!trustOnly || revocableTrustDecisionApplies}
                    showInapplicable={showInapplicable}
                  >
                  <label key={key} className="flex items-start gap-3 rounded-md border border-border bg-muted px-3 py-2.5">
                    <Checkbox
                      checked={estatePlanSetup.ancillary_documents[key]}
                      onCheckedChange={value => updateAncillaryDocument(key, value === true)}
                    />
                    <span className="text-sm text-foreground">{ANCILLARY_DOCUMENT_LABELS[key]}</span>
                  </label>
                  </ApplicableDecision>
                  )
                })}
              </div>

              <div className="rounded-md border border-dashed border-border bg-muted p-4">
                <p className="mb-1 text-sm font-semibold text-foreground">Captured, Not Drafted</p>
                <p className="mb-3 text-xs text-muted-foreground">
                  Recorded on the design sheet and printed on the interview worksheet. No
                  template produces these documents yet, so ticking one does not add a draft.
                </p>
                <div className={sectionFieldGrid2}>
                  {recordOnlyKeys.map(key => (
                    <label key={key} className="flex items-start gap-3">
                      <Checkbox
                        checked={estatePlanSetup.ancillary_documents[key]}
                        onCheckedChange={value => updateAncillaryDocument(key, value === true)}
                      />
                      <span className="text-sm text-foreground">{RECORD_ONLY_DOCUMENT_LABELS[key]}</span>
                    </label>
                  ))}
                </div>
                {estatePlanSetup.ancillary_documents.comprehensive_transfer_document && (
                  <div className={`mt-4 ${sectionFieldGrid2}`}>
                    <AttorneySelect
                      fieldName="estate_plan_design.comprehensive_transfer_title"
                      label="Comprehensive Transfer Document Title"
                      value={estatePlanSetup.comprehensive_transfer_title ?? ''}
                      placeholder="Select..."
                      options={COMPREHENSIVE_TRANSFER_TITLE_OPTIONS}
                      onChange={value => updateEstatePlanSetup({
                        comprehensive_transfer_title:
                          (value || null) as EstatePlanComprehensiveTransferTitle | null,
                      })}
                    />
                  </div>
                )}
              </div>
            </div>
          </div>

          <div>
            <p className="mb-3 text-micro font-bold uppercase tracking-[0.12em] text-muted-foreground">Document Titles</p>
            <p className="mb-3 text-xs text-muted-foreground">
              How the documents are named on their own cover and signature pages. The
              defaults are what the firm drafts in Massachusetts.
            </p>
            <div className={sectionFieldGrid3}>
              <AttorneySelect
                fieldName="estate_plan_design.healthcare_directive_title"
                label="Healthcare Directive Title"
                value={estatePlanSetup.healthcare_directive_title}
                options={HEALTHCARE_DIRECTIVE_TITLE_OPTIONS}
                onChange={value => updateEstatePlanSetup({
                  healthcare_directive_title: value as EstatePlanHealthcareDirectiveTitle,
                })}
              />
              <AttorneySelect
                fieldName="estate_plan_design.poa_form"
                label="Form of Power of Attorney"
                value={estatePlanSetup.poa_form}
                options={POA_FORM_OPTIONS}
                onChange={value => updateEstatePlanSetup({ poa_form: value as EstatePlanPoaForm })}
              />
              <AttorneySelect
                fieldName="estate_plan_design.poa_title"
                label="Long-Form Power of Attorney Title"
                value={estatePlanSetup.poa_title}
                options={POA_TITLE_OPTIONS}
                onChange={value => updateEstatePlanSetup({ poa_title: value as EstatePlanPoaTitle })}
              />
            </div>
          </div>

          <div>
            <p className="mb-3 text-micro font-bold uppercase tracking-[0.12em] text-muted-foreground">Asset Transfer Documents</p>
            <p className="mb-3 text-xs text-muted-foreground">
              Selected documents are generated with the estate plan. Transfers &amp; Assignments only shows fields needed for the checked documents.
            </p>
            <AssetTransferDocumentsFields sheet={sheet} onChange={onChange} />
          </div>

          <PlanStructureFactsSection sheet={sheet} onChange={onChange} includeAssets={false} />
        </div>
      </SectionBlock>
    </DesignSectionContent>
  )
}
