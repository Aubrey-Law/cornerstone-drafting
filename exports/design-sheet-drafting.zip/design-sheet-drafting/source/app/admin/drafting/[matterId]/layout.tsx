// EXTRACTED: In Cornerstone this layout wrapped drafting in the matter
// workspace frame (shared header, stage stepper, tab bar, Details panel) via
// `loadMatterWorkspaceFrame` + `MatterWorkspaceFrame`. Those belong to the host
// app. This version keeps the staff guard and the id check and renders the
// drafting pages bare. Wrap `children` in the new app's record shell here, and
// pass `embeddedInWorkspace` to DraftingWorkspace if that shell has its own header.
import { notFound } from 'next/navigation'
import { requireStaffPage } from '@/lib/review/staff'

export default async function DraftingMatterLayout({ children, params }: { children: React.ReactNode; params: Promise<{ matterId: string }> }) {
  const { matterId } = await params
  await requireStaffPage()
  if (!/^[0-9a-f-]{36}$/i.test(matterId)) notFound()
  return <>{children}</>
}
