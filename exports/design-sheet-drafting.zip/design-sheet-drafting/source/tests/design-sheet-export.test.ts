import fs from 'node:fs'
import path from 'node:path'
import { describe, expect, it } from 'vitest'

describe('design sheet Word export', () => {
  it('adds an authenticated admin route that exports the design summary via the estate generator', () => {
    const route = fs.readFileSync(path.join(process.cwd(), 'app/api/admin/matters/[id]/design-sheet/export/route.ts'), 'utf8')

    expect(route).toContain('requireAdmin(req)')
    expect(route).toContain('buildDraftPayload')
    expect(route).toContain('generateNodeEstatePackage')
    expect(route).toContain("'design-summary'")
    expect(route).toContain('payload.design_sheet_id')
    expect(route).toContain('application/vnd.openxmlformats-officedocument.wordprocessingml.document')
    expect(route).toContain('application/zip')
    expect(route).toContain('Content-Disposition')
  })

  it('exports the two-settlor interview worksheet for a separate-trusts matter', () => {
    const route = fs.readFileSync(path.join(process.cwd(), 'app/api/admin/matters/[id]/design-sheet/export/route.ts'), 'utf8')

    expect(route).toContain("'design-summary-separate'")
    expect(route).toContain('payload.trust?.separate_trusts')

    const manifest = JSON.parse(fs.readFileSync(
      path.join(process.cwd(), 'tools/aubreylaw-docgeneration/packages/design-summary-separate.json'),
      'utf8',
    )) as { documents: Array<{ template: string }> }
    expect(manifest.documents.map(document => document.template)).toContain(
      'templates/design-summary-worksheet-separate.docx',
    )
  })

  it('wires the design sheet screen button to save first and then download the Word export', () => {
    const shell = fs.readFileSync(path.join(process.cwd(), 'app/admin/drafting/[matterId]/design/DesignSheetPage.tsx'), 'utf8')
    const state = fs.readFileSync(path.join(process.cwd(), 'lib/designSheet/useDesignSheetState.ts'), 'utf8')

    expect(shell).toContain('onExport={handleExportDesignSheet}')
    expect(shell).toContain('DesignToolbarActions')
    expect(state).toContain('const exportDesignSheet = useCallback(async (format?:')
    expect(state).toContain('const saved = await persistSheet()')
    expect(state).toContain('/api/admin/matters/${matterId}/design-sheet/export')
  })

  it('offers a generator-data JSON export alongside the Word export', () => {
    const route = fs.readFileSync(path.join(process.cwd(), 'app/api/admin/matters/[id]/design-sheet/export/route.ts'), 'utf8')
    const shell = fs.readFileSync(path.join(process.cwd(), 'app/admin/drafting/[matterId]/design/DesignSheetPage.tsx'), 'utf8')
    const state = fs.readFileSync(path.join(process.cwd(), 'lib/designSheet/useDesignSheetState.ts'), 'utf8')
    const toolbar = fs.readFileSync(path.join(process.cwd(), 'components/guided/DesignToolbarActions.tsx'), 'utf8')

    // The route returns the raw toEstateGeneratorData() object when asked for json.
    expect(route).toContain("req.nextUrl.searchParams.get('format')")
    expect(route).toContain("format === 'json'")
    expect(route).toContain('Generator-Data-')
    // The hook exposes a JSON variant that reuses the same save-then-download flow.
    expect(state).toContain("const handleExportGeneratorData = useCallback(() => exportDesignSheet('json')")
    expect(state).toContain("const query = format ? `?format=${format}` : ''")
    // The screen wires it into the toolbar's export menu.
    expect(shell).toContain('onExportJson={handleExportGeneratorData}')
    expect(toolbar).toContain('Export generator data (JSON)')
  })

  it('offers a docx-wrapped generator-data export that Mike uploads accept', () => {
    const route = fs.readFileSync(path.join(process.cwd(), 'app/api/admin/matters/[id]/design-sheet/export/route.ts'), 'utf8')
    const shell = fs.readFileSync(path.join(process.cwd(), 'app/admin/drafting/[matterId]/design/DesignSheetPage.tsx'), 'utf8')
    const state = fs.readFileSync(path.join(process.cwd(), 'lib/designSheet/useDesignSheetState.ts'), 'utf8')
    const toolbar = fs.readFileSync(path.join(process.cwd(), 'components/guided/DesignToolbarActions.tsx'), 'utf8')

    // The route wraps the same generator JSON in a minimal Word document,
    // because Mike's uploads only accept office file types.
    expect(route).toContain("format === 'json-docx'")
    expect(route).toContain('JSON.stringify(data, null, 2)')
    expect(route).toContain('Packer.toBuffer')
    expect(state).toContain("exportDesignSheet('json-docx')")
    expect(shell).toContain('onExportJsonDocx={handleExportGeneratorDataDocx}')
    expect(toolbar).toContain('Export generator data for Mike (.docx)')
  })
})
