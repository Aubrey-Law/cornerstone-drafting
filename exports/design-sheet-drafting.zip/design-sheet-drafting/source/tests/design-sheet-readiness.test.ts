import { describe, expect, it } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import { computeDesignSheetReadiness, parseDesignFocusParam } from '@/lib/designSheetReadiness'
import { MATTER_TYPE_REQUIRED_MESSAGE } from '@/lib/matter/matterType'
import { setDesignPlanTrack } from '@/lib/collegePrepDesign'
import { designGroupForLayout } from '@/lib/designSheet/designSectionNav'
import { DESIGN_SECTION_IDS } from '@/lib/designSheet/sectionIds'
import type { DesignSheet, PipelineMatter } from '@/types/database'

function makeMatter(overrides: Partial<PipelineMatter> = {}): PipelineMatter {
  return {
    matter_id: 'matter-1',
    matter_name: 'Doe Estate Plan',
    stage: 'design',
    status: 'active',
    flags: null,
    matter_created: '2026-06-01T00:00:00.000Z',
    client_name: 'Jane Doe',
    client_email: 'jane@example.com',
    client_phone: '(555) 555-5555',
    client_dob: '1980-01-01',
    client_address: '1 Main St',
    spouse_name: null,
    spouse_email: null,
    spouse_phone: null,
    spouse_dob: null,
    spouse_address: null,
    plan_type: 'Estate Planning',
    marital_status: 'Single',
    has_minor_children: false,
    taxable_estate: null,
    intake_status: 'submitted',
    design_status: 'in_progress',
    intake_submitted_at: '2026-06-01T00:00:00.000Z',
    drafts_sent_at: null,
    signing_date: null,
    documents_executed_at: null,
    next_appointment: null,
    next_appointment_type: null,
    referral_source: null,
    fee_amount: null,
    opened_at: '2026-06-01T00:00:00.000Z',
    ...overrides,
  }
}

function makeSheet(overrides: Partial<DesignSheet> = {}): DesignSheet {
  return {
    id: 'sheet-1',
    matter_id: 'matter-1',
    version: 1,
    status: 'draft',
    client_name: 'Jane Doe',
    client_dob: '1980-01-01',
    client_phone: '(555) 555-5555',
    client_email: 'jane@example.com',
    client_citizenship: 'US Citizen',
    client_domicile: 'Massachusetts',
    street: '1 Main St',
    city: 'Boston',
    state: 'MA',
    zip: '02108',
    county: 'Suffolk',
    marital_status: 'Single',
    matter_type: 'individual',
    spouse_name: null,
    spouse_dob: null,
    spouse_phone: null,
    spouse_email: null,
    spouse_citizenship: null,
    marriage_date: null,
    children: [],
    trustee_primary: null,
    trustee_co: null,
    trustee_alt1: null,
    trustee_alt1_co: null,
    trustee_alt2: null,
    executor_primary: null,
    executor_co: null,
    executor_alt1: null,
    executor_alt1_co: null,
    executor_same_as_trustee: false,
    spouse_executor_same_as_trustee: false,
    poa_primary: null,
    poa_co: null,
    poa_alt1: null,
    poa_same_as_trustee: false,
    spouse_poa_same_as_trustee: false,
    hcp_primary: null,
    hcp_co: null,
    hcp_alt1: null,
    hcp_alt1_co: null,
    guardian_primary: null,
    guardian_co: null,
    guardian_alt1: null,
    guardian_alt1_co: null,
    plan_type: 'pour_over',
    is_joint: false,
    trust_name: 'The Jane Doe Revocable Trust',
    spouse_trust_name: null,
    restatement: false,
    trust_protector: false,
    distribution_age: null,
    include_child_gender_markers: 'no',
    include_afterborn_children: 'yes',
    include_expectant_children: 'yes',
    omissions_intentional: 'no',
    include_general_disinheritance: 'yes',
    disinherited_children: [],
    disinherit_issue: 'no',
    additional_disinheritance_language: null,
    include_additional_beneficiaries: 'no',
    additional_beneficiaries: [],
    stagger_age_1: null,
    stagger_pct_1: null,
    stagger_age_2: null,
    stagger_pct_2: null,
    stagger_age_3: null,
    tangible_property_distribution: 'memorandum',
    tangible_property_named_individual: null,
    include_common_disaster: 'yes',
    include_guardians_allowance: 'yes',
    beneficiary_as_cotrustee: 'no',
    beneficiary_as_sole_trustee: 'no',
    remote_beneficiary: 'heirs_at_law',
    provision_lifestyle_disability: 'no',
    provision_substance_abuse: 'no',
    provision_married_beneficiary: 'no',
    client_aka: null,
    spouse_aka: null,
    client_pronouns: null,
    spouse_pronouns: null,
    former_spouse_name: null,
    deceased_spouse_name: null,
    signing_date: null,
    signing_month: null,
    signing_year: null,
    signing_county: null,
    notary_commission_expiration: null,
    dpoa_coagent_manner: 'independently',
    dpoa_include_self_dealing: true,
    dpoa_self_dealing_reviewer: 'Alex Reviewer',
    dpoa_self_dealing_reviewer_alt: null,
    dpoa_include_section_l: 'no',
    hcp_anatomical_gift: 'none',
    hcp_anatomical_specified: null,
    hipaa_psychotherapy_notes: 'do_not_authorize',
    specific_bequests: [],
    pet_care_option: 'omit',
    pet_care_details: {},
    pr_structure: 'single',
    bond: 'no_bond',
    supervision: 'unsupervised',
    simultaneous_death: 'omit',
    utma_age: 21,
    no_contest_clause: 'omit',
    include_disclaimer_article: true,
    include_self_proving_affidavit: true,
    excluded_guardian_flag: false,
    excluded_guardian_name: null,
    trust_date: '2026-06-01',
    pour_over_alternate_disposition: 'spouse_then_descendants',
    pour_over_alternate_named: null,
    outright_residuary: null,
    outright_residuary_named: null,
    outright_residuary_alternate: null,
    trustee_structure: null,
    cotrustee_decision_standard: null,
    beneficiary_structure: null,
    single_beneficiary_name: null,
    single_beneficiary_remainder: null,
    age_distribution_schedule: null,
    trust_protector_name: null,
    disinheritances: null,
    fiduciary_slot_states: null,
    decisions: {
      trust_details: { residual_beneficiary_method: 'staggered' },
      document_inclusions: {
        trust: true,
        will: true,
        dpoa: true,
        healthcare: true,
        deed: false,
        spouse_docs: false,
      },
      dpoa_provisions: {
        all_basic_powers: true,
      },
      healthcare_provisions: {
        client_advance_directive: 'prolong_life',
      },
    },
    trustee_slots: [{ id: 'trustee-1', contact_id: 'contact-trustee', is_co: false, order: 0 }],
    executor_slots: [{ id: 'executor-1', contact_id: 'contact-executor', is_co: false, order: 0 }],
    poa_slots: [{ id: 'poa-1', contact_id: 'contact-poa', is_co: false, order: 0 }],
    hcp_slots: [{ id: 'hcp-1', contact_id: 'contact-hcp', is_co: false, order: 0 }],
    guardian_slots: [{ id: 'guardian-1', contact_id: null, is_co: false, order: 0 }],
    temporary_guardian_slots: [{ id: 'temp-guardian-1', contact_id: null, is_co: false, order: 0 }],
    spouse_trustee_slots: [{ id: 'spouse-trustee-1', contact_id: null, is_co: false, order: 0 }],
    spouse_executor_slots: [{ id: 'spouse-executor-1', contact_id: null, is_co: false, order: 0 }],
    spouse_poa_slots: [{ id: 'spouse-poa-1', contact_id: null, is_co: false, order: 0 }],
    spouse_hcp_slots: [{ id: 'spouse-hcp-1', contact_id: null, is_co: false, order: 0 }],
    overrides: {},
    goals_notes: 'Avoid probate.',
    concerns: 'Keep drafting simple.',
    assets: [],
    created_at: '2026-06-01T00:00:00.000Z',
    updated_at: '2026-06-01T00:00:00.000Z',
    ...overrides,
  }
}

describe('computeDesignSheetReadiness', () => {
  it('surfaces missing client decisions and fields as advisory blockers', () => {
    const readiness = computeDesignSheetReadiness({
      sheet: makeSheet({
        client_email: null,
        trust_name: null,
        dpoa_coagent_manner: null,
        decisions: {
          dpoa_provisions: {
            agent_compensation: null,
            coagent_serving: null,
            all_basic_powers: false,
            basic_powers: {},
          },
          healthcare_provisions: {
            client_anatomical_gift: null,
            client_advance_directive: null,
          },
        },
        hcp_anatomical_gift: null,
      }),
      matter: makeMatter(),
      isLP: false,
      lpData: null,
    })

    expect(readiness.complete).toBe(false)
    const labels = readiness.blockers.map(item => item.label)
    expect(labels).toContain('email')
    expect(labels).toContain('trust name')
    // Client decisions are advisory (category 'client-decision'), still reported so the UI can hint.
    expect(readiness.blockers.some(item => item.category === 'client-decision')).toBe(true)
    // Every blocker carries a jump target so the design sheet can scroll to the field.
    expect(readiness.blockers.every(item => item.targetId.length > 0)).toBe(true)
  })

  it('holds drafting when an "other" advance directive has no instructions behind it', () => {
    // `other` is truthy, so it satisfies the directive blocker on its own — but
    // the three hcp_*_advance_* flags are all false for it and the text renders
    // through `| optional`, so an empty one drafts no life-support language and
    // leaves no [[ MISSING ]] marker. The only shape where answering a question
    // makes the document less complete than leaving it blank.
    const withoutText = computeDesignSheetReadiness({
      sheet: makeSheet({
        decisions: {
          document_inclusions: { healthcare: true },
          healthcare_provisions: { client_advance_directive: 'other' },
        },
      }),
      matter: makeMatter(),
      isLP: false,
      lpData: null,
    })

    const missing = withoutText.blockers.find(
      item => item.targetField === 'healthcare_provisions.client_advance_directive_other',
    )
    expect(missing).toBeDefined()
    expect(missing!.blocking).toBe(true)
    // It points at the text, not the direction: the direction is answered.
    expect(withoutText.blockers.map(item => item.targetField))
      .not.toContain('healthcare_provisions.client_advance_directive')

    const withText = computeDesignSheetReadiness({
      sheet: makeSheet({
        decisions: {
          document_inclusions: { healthcare: true },
          healthcare_provisions: {
            client_advance_directive: 'other',
            client_advance_directive_other: 'Continue while recovery remains possible.',
          },
        },
      }),
      matter: makeMatter(),
      isLP: false,
      lpData: null,
    })
    expect(withText.blockers.map(item => item.targetField))
      .not.toContain('healthcare_provisions.client_advance_directive_other')

    // A standard direction never needs the text.
    const standard = computeDesignSheetReadiness({
      sheet: makeSheet({
        decisions: {
          document_inclusions: { healthcare: true },
          healthcare_provisions: { client_advance_directive: 'do_not_prolong_life' },
        },
      }),
      matter: makeMatter(),
      isLP: false,
      lpData: null,
    })
    expect(standard.blockers.map(item => item.targetField))
      .not.toContain('healthcare_provisions.client_advance_directive_other')
  })

  it('reports a guardian blocker when minor children lack a guardian nomination', () => {
    const readiness = computeDesignSheetReadiness({
      sheet: makeSheet({
        children: [{ name: 'Alex Doe', dob: '2015-01-01', relationship: 'biological', is_minor: true }],
        guardian_slots: [{ id: 'guardian-1', contact_id: null, is_co: false, order: 0 }],
      }),
      matter: makeMatter({ has_minor_children: true }),
      isLP: false,
      lpData: null,
    })

    expect(readiness.complete).toBe(false)
    expect(readiness.blockers.map(item => item.label)).toContain('guardian')
  })

  it('reports complete with no blockers when included document requirements are met', () => {
    const readiness = computeDesignSheetReadiness({
      sheet: makeSheet(),
      matter: makeMatter(),
      isLP: false,
      lpData: null,
    })

    expect(readiness.complete).toBe(true)
    expect(readiness.blocking).toHaveLength(0)
    expect(readiness.optional.length).toBeGreaterThan(0)
  })

  it('blocks when matter type is unset and points at that field', () => {
    const readiness = computeDesignSheetReadiness({
      sheet: makeSheet({ matter_type: null }),
      matter: makeMatter(),
      isLP: false,
      lpData: null,
    })

    const item = readiness.blocking.find(blocker => blocker.targetField === 'matter_type')
    expect(item?.label).toBe(MATTER_TYPE_REQUIRED_MESSAGE)
    expect(item?.sectionId).toBe(DESIGN_SECTION_IDS.clientInformation)
    expect(readiness.complete).toBe(false)
  })

  it('does not block a college preparation plan on matter type', () => {
    const base = makeSheet({ matter_type: null })
    const readiness = computeDesignSheetReadiness({
      sheet: makeSheet({
        matter_type: null,
        decisions: setDesignPlanTrack(base, 'college_prep'),
      }),
      matter: makeMatter(),
      isLP: false,
      lpData: null,
    })

    expect(readiness.blocking.map(item => item.targetField)).not.toContain('matter_type')
    expect(readiness.blockers.map(item => item.label)).not.toContain(MATTER_TYPE_REQUIRED_MESSAGE)
  })

  it('does not gate LP drafting on design-sheet approval (now a separate client design review)', () => {
    const lpData = {
      li_design_sheet_data: {
        residuary_spouse_survives: 'To my spouse.',
        residuary_no_spouse: 'To my descendants.',
      },
    }
    const readiness = computeDesignSheetReadiness({
      sheet: makeSheet(),
      matter: makeMatter(),
      isLP: true,
      lpData,
    })

    // Approval moved to the client-facing design review; lite never blocks on readiness.
    expect(readiness.blocking).toEqual([])
    expect(readiness.complete).toBe(true)
  })

  it('classifies a missing backup trustee as optional', () => {
    const readiness = computeDesignSheetReadiness({
      sheet: makeSheet({
        trustee_slots: [{ id: 'trustee-1', contact_id: 'contact-trustee', is_co: false, order: 0 }],
      }),
      matter: makeMatter(),
      isLP: false,
      lpData: null,
    })

    expect(readiness.optional.find(item => item.label === 'backup trustee')?.blocking).toBe(false)
    expect(readiness.blocking.map(item => item.label)).not.toContain('backup trustee')
  })

  it('classifies a missing successor trustee as blocking', () => {
    const readiness = computeDesignSheetReadiness({
      sheet: makeSheet({ trustee_slots: [] }),
      matter: makeMatter(),
      isLP: false,
      lpData: null,
    })

    expect(readiness.blocking.find(item => item.label === 'successor trustee')?.blocking).toBe(true)
  })

  it('treats non-zero order as the primary slot for PR, POA, and HCP readiness checks', () => {
    const readiness = computeDesignSheetReadiness({
      sheet: makeSheet({
        executor_slots: [
          { id: 'executor-1', contact_id: 'contact-executor', is_co: false, order: 4 },
        ],
        poa_slots: [
          { id: 'poa-1', contact_id: 'contact-poa', is_co: false, order: 5 },
        ],
        hcp_slots: [
          { id: 'hcp-1', contact_id: 'contact-hcp', is_co: false, order: 6 },
        ],
      }),
      matter: makeMatter(),
      isLP: false,
      lpData: null,
    })

    expect(readiness.complete).toBe(true)
    const blockingLabels = readiness.blocking.map(item => item.label)
    expect(blockingLabels).not.toContain('personal representative')
    expect(blockingLabels).not.toContain('first attorney-in-fact')
    expect(blockingLabels).not.toContain('first health care agent')
  })

  it('classifies a missing signing date as optional', () => {
    const readiness = computeDesignSheetReadiness({
      sheet: makeSheet({ signing_date: null }),
      matter: makeMatter(),
      isLP: false,
      lpData: null,
    })

    expect(readiness.optional.find(item => item.label === 'signing date')?.blocking).toBe(false)
    expect(readiness.blocking.map(item => item.label)).not.toContain('signing date')
  })

  it('sends joint or separate trusts to the Trust section', () => {
    const readiness = computeDesignSheetReadiness({
      sheet: makeSheet({ matter_type: 'couple', is_joint: null, spouse_name: 'Alex Doe' }),
      matter: makeMatter({ spouse_name: 'Alex Doe' }),
      isLP: false,
      lpData: null,
    })

    const item = readiness.blocking.find(entry => entry.label === 'joint or separate trusts')
    expect(item?.sectionId).toBe(DESIGN_SECTION_IDS.trustDetails)
    expect(item?.targetField).toBe('is_joint')
    expect(designGroupForLayout(item?.sectionId, 'full')).toBe('trust')
    expect(designGroupForLayout(item?.sectionId, 'essential')).toBe('essential-plan')
  })

  it('sends signing decisions to Review & sign', () => {
    const readiness = computeDesignSheetReadiness({
      sheet: makeSheet({ signing_date: null }),
      matter: makeMatter(),
      isLP: false,
      lpData: null,
    })

    for (const label of ['signing type', 'signing date', 'signing county', 'notary commission expiration']) {
      const item = readiness.optional.find(entry => entry.label === label)
      expect(item?.sectionId).toBe(DESIGN_SECTION_IDS.signing)
      expect(designGroupForLayout(item?.sectionId, 'full')).toBe('review')
      expect(designGroupForLayout(item?.sectionId, 'essential')).toBe('review')
    }
  })
})

describe('design sheet readiness UI wiring', () => {
  it('surfaces readiness blockers as advisory hints without gating generation', () => {
    const shell = fs.readFileSync(
      path.join(process.cwd(), 'app/admin/drafting/[matterId]/design/DesignSheetPage.tsx'),
      'utf8',
    )
    const workspace = fs.readFileSync(
      path.join(process.cwd(), 'app/admin/drafting/[matterId]/DraftingWorkspace.tsx'),
      'utf8',
    )
    const sharedControls = fs.readFileSync(
      path.join(process.cwd(), 'app/admin/drafting/[matterId]/design/sections/shared.tsx'),
      'utf8',
    )
    const personal = fs.readFileSync(
      path.join(process.cwd(), 'app/admin/drafting/[matterId]/design/sections/PersonalSection.tsx'),
      'utf8',
    )
    const dpoaProvisions = fs.readFileSync(
      path.join(process.cwd(), 'app/admin/drafting/[matterId]/design/sections/DpoaProvisionsSection.tsx'),
      'utf8',
    )
    const healthcare = fs.readFileSync(
      path.join(process.cwd(), 'app/admin/drafting/[matterId]/design/sections/HealthCareDesignSection.tsx'),
      'utf8',
    )

    expect(workspace).toContain('computeDesignSheetReadiness')
    expect(shell).toContain('blockingCount')
    expect(shell).toContain('blockingDetails')
    expect(shell).toContain('optionalDetails')
    // Blockers hint, never gate: generation must not be disabled by readiness.
    expect(shell).not.toContain('generateDisabled={!readinessComplete}')
    expect(sharedControls).toContain('designFieldTargetId')
    expect(personal).toContain('fieldId="client_email"')
    expect(personal).toContain('fieldId="marital_status"')
    expect(dpoaProvisions).toContain('Compensation for Agents')
    expect(dpoaProvisions).toContain('Trust Powers')
    expect(healthcare).toContain('HIPAA Authorization')
    expect(healthcare).toContain('Advance Health Directive')
  })

  it('preserves blocker focus in standalone navigation and handles each changing focus token', () => {
    const shell = fs.readFileSync(
      path.join(process.cwd(), 'app/admin/drafting/[matterId]/design/DesignSheetPage.tsx'),
      'utf8',
    )

    expect(shell).toContain('if (!targetId) target.tabIndex = -1')
    expect(shell).not.toContain('handledFocusToken.current === focusToken')
    expect(shell).not.toContain('const initialFocusHandled = useRef(false)')
  })
})

describe('parseDesignFocusParam', () => {
  it('parses section and field from drafting Fix links', () => {
    expect(parseDesignFocusParam('personal:county')).toEqual({
      sectionId: DESIGN_SECTION_IDS.clientInformation,
      targetField: 'county',
    })
  })

  it('parses section-only focus when target field is blank', () => {
    expect(parseDesignFocusParam('trust:')).toEqual({
      sectionId: DESIGN_SECTION_IDS.trustDetails,
      targetField: null,
    })
  })

  it('returns null for empty or missing values', () => {
    expect(parseDesignFocusParam(null)).toBeNull()
    expect(parseDesignFocusParam('')).toBeNull()
    expect(parseDesignFocusParam('   ')).toBeNull()
  })
})

// The gate used to be `!hasText(sheet.distribution_method)`, so any non-empty string
// satisfied it — including 'per stirpes', left over from when this column carried the
// representation type. The attorney was never prompted and the generator quietly fell
// back to a staged distribution.
describe('distribution method readiness', () => {
  const readinessFor = (overrides: Partial<DesignSheet>) => computeDesignSheetReadiness({
    sheet: makeSheet(overrides),
    matter: makeMatter(),
    isLP: false,
    lpData: null,
  })

  const blocksOnMethod = (overrides: Partial<DesignSheet>) =>
    readinessFor(overrides).blocking.some(item => item.label === 'distribution method')

  it('blocks when no method is set', () => {
    expect(blocksOnMethod({ decisions: {} })).toBe(true)
  })

  it('blocks on a value that is not a residual beneficiary method', () => {
    expect(blocksOnMethod({
      decisions: { trust_details: { residual_beneficiary_method: 'per stirpes' } },
    })).toBe(true)
  })

  it('accepts a valid method', () => {
    expect(blocksOnMethod({
      decisions: { trust_details: { residual_beneficiary_method: 'staggered' } },
    })).toBe(false)
  })

  it('accepts the legacy hyphenated spelling', () => {
    expect(blocksOnMethod({
      decisions: { trust_details: { residual_beneficiary_method: 'trust-for-life' } },
    })).toBe(false)
  })
})
